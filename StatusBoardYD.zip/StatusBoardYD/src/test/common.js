// -----------------------------------------------------------
// 문자열에서 공백 체크
// -----------------------------------------------------------
function delSpace(str) { 
	var result = null;

	for (i=0; i<str.length; i++) { 
		if (str.charAt(i) != ' ') { 
			result = str.substring(i, str.length);
			break;
		}
	}

	return result;
}

// -----------------------------------------------------------
// 문자열에서 좌/우의 공백/캐리지리턴 제거
// -----------------------------------------------------------
function trim(str) {
	return str.replace(/(^\s*)/g, "").replace(/\s*$/g, "");
}

// -----------------------------------------------------------
// str에 chars 문자가 포함되어 있는지 체크
// -----------------------------------------------------------
function containsCharsOnly(str, chars) {
    for (var inx = 0; inx < str.length; inx++) {
       if (chars.indexOf(str.charAt(inx)) == -1)
           return false;
    }
    return true;
}

// -----------------------------------------------------------
// 공백 제거
// onblur="delSpace2(this)"
// -----------------------------------------------------------
function delSpace2(obj) { 
	obj.value = obj.value.replace(/\s/g,''); 
}

// -----------------------------------------------------------
// Null 체크
// -----------------------------------------------------------
function isNull(str) { 
	var strResult = delSpace(str);
	var isnull = false;

	if (strResult == null) {
		isnull = true;
	} else if (strResult.length < 1) {
		isnull = true;
	}

	return isnull;
}

// -----------------------------------------------------------
// 전자메일주소 체크
// -----------------------------------------------------------
function isEmailAddress(str) {
	if (! isNull(str)) {
		var supported = 0

		if (window.RegExp) { 
			var tempStr = "a"
			var tempReg = new RegExp(tempStr);

			if (tempReg.test(tempStr))
				supported = 1
		}

		if (!supported)
			return (str.indexOf(".") > 2) && (str.indexOf("@") > 0);

		var r1 = new RegExp("(@.*@)|(\\.\\.)|(@\\.)|(^\\.)");
		var r2 = new RegExp("^.+\\@(\\[?)[a-zA-Z0-9\\-\\.]+\\.([a-zA-Z]{2,3}|[0-9]{1,3})(\\]?)$");

		return (!r1.test(str) && r2.test(str));
	} else {
		return true;
	}
}

//--------------------------------------------------------
//숫자 체크(이벤트 체크)
//--------------------------------------------------------
function onlyNumberInput2(Ev)
{
    if (window.event) {
        var code = window.event.keyCode;
	} else { // 타브라우저
        var code = Ev.which;
	}
    if ((code > 34 && code < 41) || (code > 47 && code < 58) || (code > 95 && code < 106) || code == 8 || code == 9 || code == 13 || code == 46) {
        window.event.returnValue = true;
        return;
    }else{
		 window.event.returnValue = false;
		 return false;
	}
}

// -----------------------------------------------------------
// 숫자 체크(값 체크)
// -----------------------------------------------------------
function isNumber(str) { 
    var chars = ",.0123456789-";
    return containsCharsOnly(str,chars);
}

// -----------------------------------------------------------
// 숫자 체크
// onkeyup="isNumber2(this)"
// -----------------------------------------------------------
function isNumber2(obj) {
	var valid = ",.0123456789-" // 유효한 값 
	var ok = "yes"; 
	var temp; 

	for (var i=0; i<obj.value.length; i++) { 
		temp = "" + obj.value.substring(i, i+1); 
		if (valid.indexOf(temp) == "-1") ok = "no"; 
	} 

	if (ok == "no") { 
		alert("숫자만 입력 가능합니다"); 
		obj.focus(); 
		obj.select()
	}
}

// -----------------------------------------------------------
// 숫자 체크
// onkeyup="isNumberChk(this)"
// -----------------------------------------------------------
function isNumberChk(obj) {
	var valid = "0123456789" // 유효한 값 
	var ok = "yes"; 
	var temp; 

	for (var i=0; i<obj.value.length; i++) { 
		temp = "" + obj.value.substring(i, i+1); 
		if (valid.indexOf(temp) == "-1") ok = "no"; 
	} 

	if (ok == "no") { 
		obj.value = "";
		alert("숫자만 입력 가능합니다");
		obj.focus(); 
		obj.select()
	}
}

// -----------------------------------------------------------
// 숫자 3자리마다 콤마 넣기
// -----------------------------------------------------------
function numberFormat(str) {
	var reg = /(\-?\d+)(\d{3})($|\.\d+)/;
	
	if (reg.test(str)) {
		return str.replace(/(\d)(?=(?:\d{3})+(?!\d))/g,'$1,');
    } else {
		return str;
	}
}

// -----------------------------------------------------------
// 숫자 3자리마다 콤마 넣기
// onkeyup="numberFormat2(this)" onkeydown="numberFormat2(this)"
// -----------------------------------------------------------
function numberFormat2(obj) {
	var reg = /(^[+-]?\d+)(\d{3})/;

	num = obj.value.replace(/,/gi,'');

	n = String(num);

	while (reg.test(n)) {
		n = n.replace(reg, '$1' + ',' + '$2');
	}

	obj.value = n;
}

// -----------------------------------------------------------
// 화폐 3자리마다 콤마 넣기, (-) 처리
// onkeyup="numberFormat3(this)" onkeydown="numberFormat3(this)"
// -----------------------------------------------------------
function numberFormat3(obj) {
	var reg = /(^[+-]?\d+)(\d{3})/;

	n = String(obj.value.replace(/,/gi,''));

	while (reg.test(n)) {
		n = n.replace(reg, '$1' + ',' + '$2');
	}

	if (/-/.test(n)) {
		n = n.replace(/-/gi,'');
		obj.value = '-' + n;
	} else {
		obj.value = n;
	}
}

// -----------------------------------------------------------
// 환율 체크
// -----------------------------------------------------------
function isKRW(str) {
    var chars = ".0123456789";
    return containsCharsOnly(str,chars);
}

// -----------------------------------------------------------
// 날짜 체크
// -----------------------------------------------------------
function resetDate(obj) {
	var date = obj.value;
	date = date.replace(/\s/g,'')
	var dateLen = date.length;

	if (isNull(date)) return true;
	if (dateLen < 2) return false; 

	var retdate = null;
	var d = new Date();
	var month = d.getMonth()+1;
	var year = d.getYear();
	
	if ((""+month).length == 1) {
		month = '0' + month;
	}

	var format1 = /^[0-9]{4}-[0-9]{2}-[0-9]{2}$/; // 2011-10-15
	var format2 = /^[0-9]{2}-[0-9]{2}$/; // 10-15
	var format3 = /^[0-9]{1}-[0-9]{2}$/; // 9-15 -> 09-15
	var format4 = /^[0-9]{1}-[0-9]{1}$/; // 9-1 -> 09-01
	var format5 = /^[0-9]{2}-[0-9]{1}$/; // 09-1 -> 09-01
	var format6 = /^[0-9]{4}$/; // 1015 -> 10-15

	if (format1.test(date)) {
		return true;			
	} else if (format2.test(date)) {
		retdate = year + '-' + date;
	} else if (format3.test(date)) {
		retdate = year + '-' + '0' + date; 
	} else if (format4.test(date)) {
		var date_arr = date.split("-");
		retdate = year + '-' + '0' + date_arr[0] + '-' + '0' + date_arr[1]; 
	} else if (format5.test(date)) {
		var date_arr = date.split("-");
		retdate = year + '-' + date_arr[0] + '-' + '0' + date_arr[1]; 
	} else if (format6.test(date)) {
		retdate = year + '-' + date.substr(0,2) + '-' + date.substr(2,2); 
	} else if (format6.test(date)) {
		retdate = year + '-' + month + '-' + date;
	} else {
		return false;
	}

	obj.value = retdate;

	return true;
}

function resetDate2(obj) {
	var date = obj.value;
	date = date.replace(/\s/g,'')
	var dateLen = date.length;

	if (isNull(date)) return true;
	if (dateLen < 2) return false; 

	var retdate = null;
	var d = new Date();
	var month = d.getMonth()+1;
	
	if ((""+month).length == 1) {
		month = '0' + month;
	}

	var format2 = /^[0-9]{2}-[0-9]{2}$/; // 10-15
	var format3 = /^[0-9]{1}-[0-9]{2}$/; // 9-15 -> 09-15
	var format4 = /^[0-9]{1}-[0-9]{1}$/; // 9-1 -> 09-01
	var format5 = /^[0-9]{2}-[0-9]{1}$/; // 09-1 -> 09-01
	var format6 = /^[0-9]{4}$/; // 1015 -> 10-15

	if (format2.test(date)) {
		return true;
	} else if (format3.test(date)) {
		retdate = '0' + date; 
	} else if (format4.test(date)) {
		var date_arr = date.split("-");
		retdate = '0' + date_arr[0] + '-' + '0' + date_arr[1]; 
	} else if (format5.test(date)) {
		var date_arr = date.split("-");
		retdate = date_arr[0] + '-' + '0' + date_arr[1]; 
	} else if (format6.test(date)) {
		retdate = date.substr(0,2) + '-' + date.substr(2,2); 
	} else if (format6.test(date)) {
		retdate = month + '-' + date;
	} else {
		return false;
	}

	obj.value = retdate;

	return true;
}

// -----------------------------------------------------------
// 날짜 체크
// -----------------------------------------------------------
function isDate(str) {
    var chars = "-0123456789";
    return containsCharsOnly(str,chars);
}

// -----------------------------------------------------------
// 날짜 체크
// onkeyup="isDate2(this)"
// -----------------------------------------------------------
function isDate2(obj) {
	var valid = "-0123456789" // 유효한 값 
	var ok = "yes"; 
	var temp; 

	for (var i=0; i<obj.value.length; i++) { 
		temp = "" + obj.value.substring(i, i+1); 
		if (valid.indexOf(temp) == "-1") ok = "no"; 
	} 

	if (ok == "no") { 
		alert("숫자, '-' 만 입력 가능합니다"); 
		obj.focus(); 
		obj.select()
	} 
}

// -----------------------------------------------------------
// 시간 체크
// -----------------------------------------------------------
function isTime(str) {
    var chars = ":0123456789";

    return containsCharsOnly(str,chars);
}

// -----------------------------------------------------------
// 시간 체크
// onkeyup="isTime2(this)"
// -----------------------------------------------------------
function isTime2(obj) {
	var valid = ":0123456789" // 유효한 값 
	var ok = "yes"; 
	var temp; 

	for (var i=0; i<obj.value.length; i++) { 
		temp = "" + obj.value.substring(i, i+1); 
		if (valid.indexOf(temp) == "-1") ok = "no"; 
	} 

	if (ok == "no") { 
		alert("숫자, ':' 만 입력 가능합니다"); 
		obj.focus(); 
		obj.select()
	} 
}

// -----------------------------------------------------------
// 특수문자 체크
// -----------------------------------------------------------
function isSpecialchar(str) {
	for (i=0; i<str.length; i++) {
		if ((str.charAt(i) == "=") ||  (str.charAt(i) == "`") ||(str.charAt(i) == "!") || (str.charAt(i) == "@") ||
			(str.charAt(i) == "#") || (str.charAt(i) == "$") || (str.charAt(i) == "%") || (str.charAt(i) == "^") ||
			(str.charAt(i) == "&") || (str.charAt(i) == "*") || (str.charAt(i) == "(") || (str.charAt(i) == ")") ||
			(str.charAt(i) == "+") || (str.charAt(i) == "=") || (str.charAt(i) == "_") ||
			(str.charAt(i) == "\\") || (str.charAt(i) == "|") || (str.charAt(i) == "{") || (str.charAt(i) == "}") ||
			(str.charAt(i) == "[") || (str.charAt(i) == "]") || (str.charAt(i) == ";") || (str.charAt(i) == ":") ||
			(str.charAt(i) == "'") || (str.charAt(i) == "\"") || (str.charAt(i) == "<") || (str.charAt(i) == ">") ||
			(str.charAt(i) == ",") || (str.charAt(i) == ".") || (str.charAt(i) == "?") || (str.charAt(i) == "/") || (str.charAt(i) == " "))
			return	true;
	}

	return	false;
}

// -----------------------------------------------------------
// 이미지 파일 체크
// -----------------------------------------------------------
function isValidFile(ftype, str) {
	if (! isNull(str)) {
		switch(ftype) {
			case "image" : // 이미지 파일
				var extension = "\.(bmp|gif|jpg|jpeg|png)$"; 
				break;
			case "general" : // 일반파일
				break;
		}	
		
		if (!(new RegExp(extension, "i")).test(str)) {
			return false;
		} 
	}

	return true;
}

// -----------------------------------------------------------
// 화면 가운데에 새창 열기
// javascript:windowOpen('index.asp',400,400,0,0)
// -----------------------------------------------------------
function windowOpen(page,w,h,s,r) {
    var win = "_blank";
	var l = (screen.width) ? (screen.width-w)/2 : 0; 
	var t = (screen.height) ? (screen.height-h)/2 : 0; 
    var settings='';
    
    settings ='width='+w+','; 
    settings +='height='+h+',';
    settings +='top='+t+','; 
    settings +='left='+l+','; 
    settings +='scrollbars='+s+','; 
    settings +='resizable='+r+','; 
    settings +='status=1';

	var windows = window.open(page,win,settings);
    windows.focus();
}

// -----------------------------------------------------------
// 입력/수정폼의 필수입력항목 체크
// -----------------------------------------------------------
function isValidForm(frm) {
    var isValid = true;
	var frmElmLength = frm.elements.length;

	// 폼 요소의 유효성 체크
	for (var i = 0; i < frmElmLength; i++) {
		// 필수 항목 체크
		if (frm.elements[i].getAttribute("required") != null && frm.elements[i].getAttribute("required") != "") {
			if (isNull(frm.elements[i].value)) {
				alert('필수 항목을 먼저 입력(선택) 하세요!');
				frm.elements[i].focus();
				isValid = false;
				break;
			}

		}
	
		// 숫자 체크
		if (isValid && frm.elements[i].getAttribute("number") != null && frm.elements[i].getAttribute("required") != "") {
			if (! isNumber(frm.elements[i].value)) {
				alert('숫자만 입력 가능합니다!');
				frm.elements[i].focus();
				isValid = false;
				break;
			}			
		}

		// 전자메일주소 체크
		if (isValid && frm.elements[i].getAttribute("email") != null && frm.elements[i].getAttribute("required") != "") {
			if (! isEmailAddress(frm.elements[i].value)) {
				alert('전자메일 주소를 정확히 입력하세요!');
				frm.elements[i].focus();
				isValid = false;
				break;
			}			
		}

		// 이미지파일 체크
		if (isValid && frm.elements[i].getAttribute("imagefile") != null && frm.elements[i].getAttribute("required") != "") {
			if (! isValidFile("image", frm.elements[i].value)) {
				alert('이미지 파일을 선택하세요!');
				frm.elements[i].focus();
				isValid = false;
				break;
			}			
		}

		// TEXTAREA의 좌우 캐리지리턴 제거
		if (frm.elements[i].tagName == "TEXTAREA") {
			frm.elements[i].value = trim(frm.elements[i].value);
		}
	}

	return isValid;
}


// -----------------------------------------------------------
// 목록의 기본설정 항목 체크
// -----------------------------------------------------------
function setDefaultElm(frm) {
	var frmElmLength = frm.elements.length;

	for (var i = 0; i < frmElmLength; i++) {
		if (frm.elements[i].getAttribute("defaultlist") != null) {
			frm.elements[i].checked = true;
			frm.elements[i].style.backgroundColor = '#ddd';
			frm.elements[i].style.borderColor = '';
			frm.elements[i].style.borderStyle = 'solid';
		} else {
			frm.elements[i].checked = false;
			frm.elements[i].style.backgroundColor = '';
			frm.elements[i].style.borderColor = '';
			frm.elements[i].style.borderStyle = '';
		}
	}
}

// -----------------------------------------------------------
// 목록의 기본설정 항목 저장체크
// -----------------------------------------------------------
function checkMyListFrm(frm) {
	var isValid = false;
	var frmElmLength = frm.elements.length;

	for (var i = 0; i < frmElmLength; i++) {
		if (frm.elements[i].checked == true) {
			isValid = true
			break;
		} 
	}

	if (! isValid) {
		alert("항목을 한 개 이상 선택하세요!");
	}

	return isValid;
}

// -----------------------------------------------------------
// 요소의 Value 삭제
// -----------------------------------------------------------
function removeObjValue(obj) {
	if (! isNull(obj.value)) {
		obj.value = '';	
	} 
	//else {
	//	alert("지정된 값이 없습니다!");
	//}

	return;
}

// -------------------------------------------------------------------
//  관리자 보이기/감추기
// -------------------------------------------------------------------
var adminFlag = false;

function showAdmin(clickObj, pidx) {
	if (! adminFlag) {
		hideAdmin();
		adminFlag = false;

		var e = window.event;
		var tooltipObj = document.getElementById("adminTooltip");
		
		try {
			var sWidth = parseInt(window.scrollMaxX) + parseInt(docElement.clientWidth);
		} catch(e) {
			var sWidth = (document.body.scrollWidth > document.body.clientWidth) ? document.body.scrollWidth : document.body.clientWidth;
		}
	   
		var posX = 0;
		var posY = 0;
		var obj = clickObj;
		
		while(obj.offsetParent) {
			posY += parseInt(obj.offsetTop);
			posX += parseInt(obj.offsetLeft);
			obj = obj.offsetParent;
		}

		posX += parseInt(obj.offsetLeft) + 1;
		posY += parseInt(obj.offsetTop);
		
		posY += clickObj.offsetHeight;
		
		//if (sWidth < posX + 150) {
			posX -= 175;
			posX += parseInt(clickObj.offsetWidth);
		//}

		tooltipObj.style.left = posX + 'px';
		tooltipObj.style.top = posY + 'px';
		tooltipObj.style.display = "block";

		document.adminFrm.target_idx.value = pidx;
	} else {
		hideAdmin();
		adminFlag = false;
	}
}

function hideAdmin() {
	document.getElementById("adminTooltip").style.display = "none";
	adminFlag = false;
}

// -----------------------------------------------------------
// 변경이력 수정/삭제
// -----------------------------------------------------------
function changeHistory(idx, mode) {
	if (mode != "" && idx != "") {
		var historyFrm = document.historyForm;

		historyFrm.idx.value = idx;
		historyFrm.memo.value = document.getElementById('memo_' + idx).value;
		historyFrm.mode.value = mode;
		historyFrm.submit();
	}
}

// -----------------------------------------------------------
// 위도/경도 좌표 값을 한글 주소 값으로 변경
// -----------------------------------------------------------
function searchCoordinateToAddress(latlng) {
    naver.maps.Service.reverseGeocode({
        coords: latlng,
        orders: [naver.maps.Service.OrderType.ADDR,
			naver.maps.Service.OrderType.ROAD_ADDR].join(',')
		}, function(status, response) {
			  if (status === naver.maps.Service.Status.ERROR) {
					if (!latlng) {return alert('ReverseGeocode Error, Please check latlng');}
					if (latlng.toString) {return alert('ReverseGeocode Error, latlng:' + latlng.toString());}
					if (latlng.x && latlng.y) {return alert('ReverseGeocode Error, x:' + latlng.x + ', y:' + latlng.y);}
					return alert('ReverseGeocode Error, Please check latlng');
			  }
			  var address = response.v2.address, htmlAddresses = [];
			  if (address.jibunAddress !== '') {
				  htmlAddresses.push('[지번 주소] ' + address.jibunAddress);
			  }
			  if (address.roadAddress !== '') {
				  htmlAddresses.push('[도로명 주소] ' + address.roadAddress);
			  }
			  infoWindow.setContent(['<div style="padding:10px;min-width:200px;line-height:150%;">'
				                     , '<h4 style="margin-top:5px;">검색 좌표</h4><br />'
									 , htmlAddresses.join('<br />'),'</div>'].join('\n'));
			  infoWindow.open(map, latlng);
		   }
    );
}

//------------------------------------------------------------------------------
//javascript 페이징 처리
//------------------------------------------------------------------------------
function paging(gotopage, pagecount, link, pagesize) {

	var intStart = (parseInt(((gotopage-1)/pagecount))*pagecount) +1;
	var intEnd = parseInt(((( gotopage - 1 ) + pagecount ) / pagecount )) * pagecount;

	prev = parseInt(gotopage) - 1;
	after = parseInt(gotopage) + 1;

    const pages = $("#pages");

    pages.empty();

    if (gotopage > 1) {
        pages.append("<li class=pagebtn>"+
								"<a href=javascript:" + link + "(" + 1 + ") target='_self'><span class=first></span></a>"+
								"<a href=javascript:" + link + "(" + prev + ") target='_self'><span class=prev></span></a>");
    }
	
	else {
		pages.append("<li class=pagebtn><a><span class=first></span></a><a><span class=prev></span></a>");
	}

	for (var start = intStart; start <= intEnd ; start++ )	{
		if (start == gotopage) {
			pages.append("<li class=on>"+start+"</li>");
		}else{
			pages.append("<li><a href=javascript:" + link + "(" + start + ") target='_self'>" + start +"</a></li>");
		} 

		if (start >= pagesize) {
			break;
		}

	}
	if(gotopage < pagesize) {
		pages.append("<li class=pagebtn>"+
								"<a href=javascript:'" + link + "(" + after + ") target='_self'><span class=next></span></a>"+
								"<a href=javascript:" + link + "(" + pagesize + ") target='_self'><span class=last></span></a>");
	}else {
		pages.append("<li class=pagebtn><a><span class=next></span></a><a><span class=last></span></a><li>")
	}
}
//------------------------------------------------------------------------------
//javascript 페이징 처리
//------------------------------------------------------------------------------
function eve_paging(gotopage, pagecount, link, pagesize) {

	var intStart = (parseInt(((gotopage-1)/pagecount))*pagecount) +1;
	var intEnd = parseInt(((( gotopage - 1 ) + pagecount ) / pagecount )) * pagecount;

	prev = parseInt(gotopage) - 1;
	after = parseInt(gotopage) + 1;

    const eve_pages = $("#eve_pages");

    eve_pages.empty();

    if (gotopage > 1) {
        eve_pages.append("<li class=pagebtn>"+
								"<a href=javascript:" + link + "(" + 1 + ") target='_self'><span class=first></span></a>"+
								"<a href=javascript:" + link + "(" + prev + ") target='_self'><span class=prev></span></a>");
    }
	
	else {
		eve_pages.append("<li class=pagebtn><a><span class=first></span></a><a><span class=prev></span></a>");
	}

	for (var start = intStart; start <= intEnd ; start++ )	{
		if (start == gotopage) {
			eve_pages.append("<li class=on>"+start+"</li>");
		}else{
			eve_pages.append("<li><a href=javascript:" + link + "(" + start + ") target='_self'>" + start +"</a></li>");
		} 

		if (start >= pagesize) {
			break;
		}

	}
	if(gotopage < pagesize) {
		eve_pages.append("<li class=pagebtn>"+
								"<a href=javascript:'" + link + "(" + after + ") target='_self'><span class=next></span></a>"+
								"<a href=javascript:" + link + "(" + pagesize + ") target='_self'><span class=last></span></a>");
	}else {
		eve_pages.append("<li class=pagebtn><a><span class=next></span></a><a><span class=last></span></a><li>")
	}
}

//------------------------------------------------------------------------------
//jquery ajax 
//request type : post
//return type : json
//------------------------------------------------------------------------------
function ajax_pj(p_url, params, success_check1, success_check2, success_msg, error_msg) {
	$.ajax({         
		type : "POST"
		,processData : false
		,contentType : 'application/x-www-form-urlencoded; charset=UTF-8'
		,cache : false
		,url : p_url
		,data: params
		,success : (res) => {
			if(res.includes(success_check1) && res.includes(success_check2)){
				alert(success_msg);
			} else {
				console.log(`success res: ${res}`);
			}
		}
		,error : (res) => {
			console.log(`error res: ${res}`);
			alert(error_msg);
		}
	});
}
