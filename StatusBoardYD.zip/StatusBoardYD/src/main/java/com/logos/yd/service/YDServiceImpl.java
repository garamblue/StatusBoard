package com.logos.yd.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

//import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;

import com.logos.yd.dao.YDDao;

@Service("YDService")
public class YDServiceImpl implements YDService{
	//Logger log = Logger.getLogger(this.getClass());
	
	@Resource(name="ydDAO")
	private YDDao ydDAO;
	
	
	@SuppressWarnings("rawtypes")
	@Override
	public <T extends List<? extends Map>> T selectMachineInfo(Map<String, Object> map) throws Exception {
		   //List<HashMap<String, Object>> selectMachineInfo(Map<String, Object> map) throws Exception {
		return ydDAO.selectMachineInfo(map);
	}
	
	@Override
	public List<HashMap<String, Object>> selectAssembleInfo(Map<String, Object> map) throws Exception {
		return ydDAO.selectAssembleInfo(map);
	}
	
	@Override
	public List<HashMap<String, Object>> selectAssembleImgInfo(Map<String, Object> map) throws Exception {
		return ydDAO.selectAssembleImgInfo(map);
	}
	
	@Override
	public List<HashMap<String, Object>> selectPressInfo(Map<String, Object> map) throws Exception {
		return ydDAO.selectPressInfo(map);
	}
	
	@Override
	public List<HashMap<String, Object>> selectAutoInfo(Map<String, Object> map) throws Exception {
		return ydDAO.selectAutoInfo(map);
	}
	
	@Override
	public List<HashMap<String, Object>> selectNonOperInfo(Map<String, Object> map) throws Exception {
		return ydDAO.selectNonOperInfo(map);
	}
	
	@Override
	public List<HashMap<String, Object>> selectNonOperGraphInfo(Map<String, Object> map) throws Exception {
		return ydDAO.selectNonOperGraphInfo(map);
	}
	
	@Override
	public Map<String, Object> selectMachineDetail(Map<String, Object> map) throws Exception {
		return ydDAO.selectMachineDetail(map);
	}
	
	@Override
	public Map<String, Object> selectSlideCnt() throws Exception {
		return ydDAO.selectSlideCnt();
	}
	
}