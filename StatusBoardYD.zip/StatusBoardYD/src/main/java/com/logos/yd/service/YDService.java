package com.logos.yd.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public interface YDService {

	//List<HashMap<String, Object>> selectMachineInfo(Map<String, Object> map) throws Exception;
	@SuppressWarnings("rawtypes")
	<T extends List<? extends Map>> T selectMachineInfo(Map<String, Object> map) throws Exception;
	
	List<HashMap<String, Object>> selectAssembleInfo(Map<String, Object> map) throws Exception;
	
	List<HashMap<String, Object>> selectAssembleImgInfo(Map<String, Object> map) throws Exception;
	
	List<HashMap<String, Object>> selectPressInfo(Map<String, Object> map) throws Exception;
	
	List<HashMap<String, Object>> selectAutoInfo(Map<String, Object> map) throws Exception;
	
	List<HashMap<String, Object>> selectNonOperInfo(Map<String, Object> map) throws Exception;
	
	List<HashMap<String, Object>> selectNonOperGraphInfo(Map<String, Object> map) throws Exception;
	
	Map<String, Object> selectMachineDetail(Map<String, Object> map) throws Exception;
	
	Map<String, Object> selectSlideCnt() throws Exception;

}