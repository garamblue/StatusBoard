package com.logos.common;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

public class DateConfirm {

	public static void main(String[] args) {
        //System.out.println(new Date().toGMTString());
        //System.out.println(new Date().getTimezoneOffset());

        java.util.TimeZone tz = java.util.TimeZone.getDefault();
        
        System.out.println("1 ============================================================");
        System.out.println("Timezone offset from UTC reported as " + (tz.getRawOffset() / 1000 / 60) + " minutes");
        
        if (tz.getRawOffset() % (15 * 60 * 1000) != 0) {
        	System.out.println("2 ============================================================");
            System.out.println("Warning: not a multiple of quarter-hours");
        }
        
        System.out.println("3 ============================================================");
        System.out.println(new java.util.Date());
        System.out.println(tz);

        TimeZone tz2;
        Date date = new Date();
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss (z Z)");

        tz2 = TimeZone.getTimeZone("Asia/Seoul");
        df.setTimeZone(tz2);
        System.out.println("4 ============================================================");
        System.out.format("%s%n%s%n%n", tz2.getDisplayName(), df.format(date));
        
        Calendar calendar = Calendar.getInstance();
		int year = calendar.get(Calendar.YEAR);
		int month = calendar.get(Calendar.MONTH) + 1;
		int day = calendar.get(Calendar.DATE);
		System.out.println("5 ============================================================");
		System.out.println("year: " + year);
		System.out.println("month: " + month);
		System.out.println("day: " + day);
		
		
		LocalDate ld = LocalDate.now();  // 날짜 구하기
		LocalTime lt = LocalTime.now();  // 시간 구하기
		
		//System.out.println("6 ============================================================");
		//System.out.println("LocalDate     > " + ld);
		//System.out.println("LocalTime     > " + lt);
		//System.out.println("LocalDateTime > " + ldt);
		LocalDateTime ldt = LocalDateTime.now();  //서버 날짜 + 시간 구하기
		System.out.println(ldt.getYear());
		System.out.println(String.valueOf(ldt.getYear()).substring(0, 2) );
		System.out.println(String.valueOf(ldt.getYear()).substring(2, 4) );
		System.out.println(ldt.getMonthValue());
		System.out.println(ldt.getDayOfMonth());
		System.out.println(ldt.getHour());
    }

}
