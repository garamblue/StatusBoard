/*
	Spectral by HTML5 UP
	html5up.net | @ajlkn
	Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)
*/

(function($) {

    $(document).ready(function() {
        
        var slider = $('#page').sliderTabs({
            autoplay:false,
            pauseOnHover:false,
            mousewheel: false,
            transitionSpeed: 0,
            transition: "fade",
            tabHeight: 60,
            height: 1140
        });
        
        $('#tabremote dd').click(function(){
            $(this).children('span').toggleClass('alt');
        });

        $('#tabremote .time ul li button').click(function(){
            $(this).toggleClass('disabled');
        });
        
        $('.modal-header>button').click(function(){
            $('.modal-layer').slideUp('fast');
        });

        $('#main a').click(function(){
            var $modallink = '.modal-layer'//$(this).attr('href');
            $($modallink).slideDown('slow');
            //$('#pop01').slideDown('slow');
        });
    
	});

})(jQuery);
